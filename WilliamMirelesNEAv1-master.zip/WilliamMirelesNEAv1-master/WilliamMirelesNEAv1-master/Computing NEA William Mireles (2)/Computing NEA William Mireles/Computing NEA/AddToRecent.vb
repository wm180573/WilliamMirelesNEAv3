﻿Public Class AddToRecent
    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        ' Define connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define location of database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"

        ' Logs the transaction into the system
        Dim sql As String = "INSERT INTO RecentGames (GameName,Price,Genre,Developer,BoughtOrSold,CustomerID,GameID) VALUES ('" & AddOrRemoveGame.txtTitle.Text & "', '" & AddOrRemoveGame.txtPrice.Text & "', '" & AddOrRemoveGame.txtGenre.Text & "', '" & AddOrRemoveGame.txtDeveloper.Text & "','" & AddOrRemoveGame.BoughtOrSold.Text & "', '" & AddOrRemoveGame.txtCustomerID.Text & "', '" & AddOrRemoveGame.txtGameID.Text & "')"

        ' Represents the SQL statement to be executed against the data base
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Staff member notified of successful logging of transaction
        MessageBox.Show("Game transaction logged into the system, you will now be redirected to the main menu", "Recording of game transaction successful")
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()

        ' Opens connection of SQL statement and database
        sqlCom.Connection = conn
        ' Opens connection to the database
        conn.Open()
        ' Executes the SQL statement
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

    End Sub

    Private Sub BtnNo_Click(sender As Object, e As EventArgs) Handles BtnNo.Click
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()
    End Sub
End Class
﻿
Public Class RequestReply
    Private Sub RequestReply()
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Defines location of the database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
        ' Opens connection to the database
        conn.Open()
        ' SQL (Structured Query Lanugage) statement which inserts what the staff member input into the database in the corresponding table
        Dim sql As String = "INSERT INTO StaffActions(StaffUser,CustUser,Message) VALUES ('" & StaffLogin.TxtUsername.Text & "', '" & txtCustUser.Text & "', """ & txtMsg.Text & """)"
        ' Allows the sql command to be executed against the database
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Staff member is notififed of their success of their required task.
        MessageBox.Show("Message sent", "Sending of message successful")
        'Open Database Connection again
        sqlCom.Connection = conn

        ' Carry out the sql statement
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

        ' Close the connection to the database
        conn.Close()
        ' Hides current form
        Me.Hide()
        ' Redirectes to form that asks them if they wish to now delete the original request from the system
        DeleteFromRequests.Show()
    End Sub

    Private Sub DoesRequestExist()
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define database location
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
        ' Returns the request that has been sent by the customer specified and has the requestID specified
        Dim sqlValidation As String = "SELECT * FROM CustRequests WHERE CustUser = '" & txtCustUser.Text & "' AND RequestID = " & txtRequestID.Text & ""
        ' Allows sql to communicate with database
        Dim sqlComValidation As New System.Data.OleDb.OleDbCommand(sqlValidation)
        ' Connects the SQL statement to the database
        sqlComValidation.Connection = conn
        'Open Database Connection
        conn.Open()
        ' Executes SQL statement against database
        Dim sqlReadValidation As System.Data.OleDb.OleDbDataReader = sqlComValidation.ExecuteReader()

        ' If the specified request is found, then the message can be sent
        If sqlReadValidation.Read() Then
            RequestReply()
            ' If the specified request isn't found, then the staff member is made aware that it doesn't exist
        Else
            MessageBox.Show("The request you've specified doesn't exist, please try again.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub
    Private Sub BtnSend_Click(sender As Object, e As EventArgs) Handles BtnSend.Click
        ' If any field is left blank, the staff member is notified that all text boxes need to be filled out before they can reply to the request
        If txtCustUser.Text = "" Or txtRequestID.Text = "" Or txtMsg.Text = "" Then
            MessageBox.Show("Please ensure all text boxes have been filled out before attempting to send the message.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' If the requestID has been entered erroneously, inform the staff member that they need to re-evaulate their input
        ElseIf IsNumeric(txtRequestID.text) = False Then
            MessageBox.Show("Please ensure the request ID is an integer, Please try again.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Otherwise, continue to the validation
        Else
            ' When BtnSend is pressed, it checks if the request specified actually exists
            DoesRequestExist()
        End If
    End Sub

    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides current form
        Me.Hide()
        ' Shows staff menu form
        StaffMenu.Show()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click

    End Sub
End Class
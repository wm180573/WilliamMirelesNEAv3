﻿Public Class StaffSearchGames
    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        ' If the user hasn't given a value for the game title of the game they wish to search for, they're informed that this must be filled out before their desired game is searched for
        If txtGameTitle.Text = "" Then
            MessageBox.Show("Please ensure that you've entered the title of the game you wish to search for", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            ' Connection is created
            Dim conn As New System.Data.OleDb.OleDbConnection()
            ' Database location defined
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
            ' SQL statement which returns all of the fields from the Games database where its name is equal to what the staff member searched
            Dim sql As String = "SELECT GameID,GameName,Price,Genre,Developer FROM Games WHERE (GameName) = ('" & txtGameTitle.Text & "')"
            ' Allows the SQL command to communicate with the database
            Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
            ' Open SQL connection
            sqlCom.Connection = conn
            'Open Database Connection
            conn.Open()
            ' Executes the SQL command to the database
            Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
            ' If the game being searched for is found then this
            If sqlRead.HasRows Then
                ' Reads through each field until all returned and then populates the relevant text boxes with each field value
                While sqlRead.Read()
                    txtGameID.Text = sqlRead.Item("GameID")
                    txtGameTitle.Text = sqlRead.Item("GameName")
                    txtPrice.Text = sqlRead.Item("Price")
                    txtGenre.Text = sqlRead.Item("Genre")
                    txtDeveloper.Text = sqlRead.Item("Developer")
                    ' User is notified of game being found
                    MessageBox.Show("Game found", "Searching of game successful")
                End While
                ' Closes the read connection
                sqlRead.Close()
            Else
                MessageBox.Show("No game called """ & txtGameTitle.Text & """" & " was found. Please try again", "Error while searching for game")
                ' All fields are cleared
                txtGameID.Clear()
                txtGameTitle.Clear()
                txtPrice.Clear()
                txtGenre.Clear()
                txtDeveloper.Clear()
                ' Closes database connection
                conn.Close()
            End If
        End If


    End Sub

    Private Sub BtnMainMenu_Click(sender As Object, e As EventArgs) Handles BtnMainMenu.Click

        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()
    End Sub
End Class
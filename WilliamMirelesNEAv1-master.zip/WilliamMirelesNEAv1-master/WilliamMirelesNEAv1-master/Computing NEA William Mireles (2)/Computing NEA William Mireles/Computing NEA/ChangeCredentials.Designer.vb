﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChangeCredentials
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnMenu = New System.Windows.Forms.Button()
        Me.BtnUpd = New System.Windows.Forms.Button()
        Me.txtNewData = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FieldName = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'BtnMenu
        '
        Me.BtnMenu.Location = New System.Drawing.Point(387, 172)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(98, 42)
        Me.BtnMenu.TabIndex = 17
        Me.BtnMenu.Text = "Main menu"
        Me.BtnMenu.UseVisualStyleBackColor = True
        '
        'BtnUpd
        '
        Me.BtnUpd.Location = New System.Drawing.Point(171, 177)
        Me.BtnUpd.Name = "BtnUpd"
        Me.BtnUpd.Size = New System.Drawing.Size(126, 32)
        Me.BtnUpd.TabIndex = 16
        Me.BtnUpd.Text = "Update"
        Me.BtnUpd.UseVisualStyleBackColor = True
        '
        'txtNewData
        '
        Me.txtNewData.Location = New System.Drawing.Point(303, 125)
        Me.txtNewData.Name = "txtNewData"
        Me.txtNewData.Size = New System.Drawing.Size(117, 20)
        Me.txtNewData.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(100, 123)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(191, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "New username/password:"
        '
        'FieldName
        '
        Me.FieldName.FormattingEnabled = True
        Me.FieldName.Items.AddRange(New Object() {"CustUser", "CustPass"})
        Me.FieldName.Location = New System.Drawing.Point(303, 87)
        Me.FieldName.Name = "FieldName"
        Me.FieldName.Size = New System.Drawing.Size(117, 21)
        Me.FieldName.TabIndex = 13
        Me.ToolTip1.SetToolTip(Me.FieldName, "CustUser is your username and CustPass is your password")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(100, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(197, 20)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Information to be updated:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(100, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(248, 31)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Change credentials"
        '
        'txtCustomerID
        '
        Me.txtCustomerID.Location = New System.Drawing.Point(1696, 547)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.ReadOnly = True
        Me.txtCustomerID.Size = New System.Drawing.Size(10, 20)
        Me.txtCustomerID.TabIndex = 18
        '
        'ChangeCredentials
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 218)
        Me.Controls.Add(Me.txtCustomerID)
        Me.Controls.Add(Me.BtnMenu)
        Me.Controls.Add(Me.BtnUpd)
        Me.Controls.Add(Me.txtNewData)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.FieldName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Name = "ChangeCredentials"
        Me.Text = "ChangeCredentials"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnMenu As Button
    Friend WithEvents BtnUpd As Button
    Friend WithEvents txtNewData As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents FieldName As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents txtCustomerID As TextBox
End Class

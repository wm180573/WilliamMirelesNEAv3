﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ViewRequestReplies
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.StaffRepliesDataGridView = New System.Windows.Forms.DataGridView()
        Me.BtnMenu = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnDelete = New System.Windows.Forms.Button()
        CType(Me.StaffRepliesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StaffRepliesDataGridView
        '
        Me.StaffRepliesDataGridView.AllowUserToAddRows = False
        Me.StaffRepliesDataGridView.AllowUserToDeleteRows = False
        Me.StaffRepliesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.StaffRepliesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.StaffRepliesDataGridView.Location = New System.Drawing.Point(37, 92)
        Me.StaffRepliesDataGridView.Name = "StaffRepliesDataGridView"
        Me.StaffRepliesDataGridView.ReadOnly = True
        Me.StaffRepliesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.StaffRepliesDataGridView.Size = New System.Drawing.Size(692, 258)
        Me.StaffRepliesDataGridView.TabIndex = 2
        '
        'BtnMenu
        '
        Me.BtnMenu.Location = New System.Drawing.Point(638, 380)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(91, 45)
        Me.BtnMenu.TabIndex = 3
        Me.BtnMenu.Text = "Main Menu"
        Me.BtnMenu.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(197, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(324, 31)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Request replies from staff"
        '
        'BtnDelete
        '
        Me.BtnDelete.Location = New System.Drawing.Point(473, 380)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(132, 45)
        Me.BtnDelete.TabIndex = 5
        Me.BtnDelete.Text = "Delete oldest reply"
        Me.BtnDelete.UseVisualStyleBackColor = True
        '
        'ViewRequestReplies
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(790, 450)
        Me.Controls.Add(Me.BtnDelete)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnMenu)
        Me.Controls.Add(Me.StaffRepliesDataGridView)
        Me.Name = "ViewRequestReplies"
        Me.Text = "ViewRequestReplies"
        CType(Me.StaffRepliesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StaffRepliesDataGridView As DataGridView
    Friend WithEvents BtnMenu As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnDelete As Button
End Class

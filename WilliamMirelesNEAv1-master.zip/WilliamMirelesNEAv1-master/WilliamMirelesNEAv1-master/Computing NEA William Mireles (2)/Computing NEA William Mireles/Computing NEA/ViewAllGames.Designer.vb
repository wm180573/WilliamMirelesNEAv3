﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewAllGames
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GamesDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnMenu = New System.Windows.Forms.Button()
        CType(Me.GamesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GamesDataGridView
        '
        Me.GamesDataGridView.AllowUserToAddRows = False
        Me.GamesDataGridView.AllowUserToDeleteRows = False
        Me.GamesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.GamesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GamesDataGridView.Location = New System.Drawing.Point(47, 116)
        Me.GamesDataGridView.Name = "GamesDataGridView"
        Me.GamesDataGridView.ReadOnly = True
        Me.GamesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GamesDataGridView.Size = New System.Drawing.Size(705, 243)
        Me.GamesDataGridView.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(249, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(206, 31)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Game database"
        '
        'BtnMenu
        '
        Me.BtnMenu.Location = New System.Drawing.Point(697, 378)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(91, 68)
        Me.BtnMenu.TabIndex = 5
        Me.BtnMenu.Text = "Main Menu"
        Me.BtnMenu.UseVisualStyleBackColor = True
        '
        'ViewAllGames
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BtnMenu)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GamesDataGridView)
        Me.Name = "ViewAllGames"
        Me.Text = "ViewAllGames"
        CType(Me.GamesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GamesDataGridView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnMenu As Button
End Class

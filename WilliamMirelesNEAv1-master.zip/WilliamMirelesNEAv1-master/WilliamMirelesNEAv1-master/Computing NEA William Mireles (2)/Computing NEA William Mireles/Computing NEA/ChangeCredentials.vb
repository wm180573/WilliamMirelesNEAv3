﻿Public Class ChangeCredentials
    ' The below procedure retrieves the customerID for the customer that is currently logged in, so this can be used for the SQL statement to change their username/password (as the user desires)
    Sub RetrieveCustomerID()
        ' Defines new connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define database location for connection
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
        ' Retrieves the CustomerID of the customer who is logged in
        Dim sql As String = "SELECT CustomerID FROM Customers WHERE (CustUser) = ('" & CustomerLogin.txtUsername.Text & "')"
        ' Allows sql command to communicate with the data source
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Connects SQL statement to database
        sqlCom.Connection = conn
        ' Open Database Connection
        conn.Open()
        ' Provides a way of reading the data rows from the database
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
        ' Executes following code if there are records found
        If sqlRead.HasRows Then
            ' This while loop populates the relevant textbox with the corresponding information from the database until finished.
            While sqlRead.Read()
                ' Places the corresponding CustomerID in an invisible textbox so it can be used later
                txtCustomerID.Text = sqlRead.Item("CustomerID")
            End While
        End If

        ' Close connection between sql and database
        sqlRead.Close()
    End Sub
    Private Sub BtnUpd_Click(sender As Object, e As EventArgs) Handles BtnUpd.Click
        ' If their new username/password is under 5 characters, they are notified that it must be longer
        If txtNewData.Text.Length < 5 Then
            MessageBox.Show("Please ensure that your new username/password is longer than 5 characters", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else
            ' Create connection to the database
#Disable Warning IDE0017 ' Simplify object initialization
            Dim conn As New System.Data.OleDb.OleDbConnection()
#Enable Warning IDE0017 ' Simplify object initialization
            ' Defines location of the database
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
            ' SQL (Structured Query Lanugage) statement which changes the value of the desired field to the desired value in the record of the customer currently logged in
            Dim sql As String = "UPDATE Customers SET " & FieldName.SelectedItem & " = """ & txtNewData.Text & """ WHERE CustomerID = " & txtCustomerID.Text & ""
            ' Executes the statement against the database
            Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

            ' Connects the sql statement to the database
            sqlCom.Connection = conn

            ' Opens the connection
            conn.Open()

            ' Staff member is notified of their success of their required task.
            MessageBox.Show("Field value updated", "Database record updation successful")

            ' Carry out the sql statement
            Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

            ' Close the connection to the database
            conn.Close()

            ' Clears all text box values to enable them to change other information in rapid succession
            FieldName.Text = ""
            txtNewData.Clear()
        End If
    End Sub

    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides current form
        Me.Hide()
        ' Redirects to customer menu
        CustomerMenu.Show()
    End Sub

    Private Sub ChangeCredentials_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' When the form loads, the CustomerID is retrieved
        RetrieveCustomerID()
    End Sub
End Class
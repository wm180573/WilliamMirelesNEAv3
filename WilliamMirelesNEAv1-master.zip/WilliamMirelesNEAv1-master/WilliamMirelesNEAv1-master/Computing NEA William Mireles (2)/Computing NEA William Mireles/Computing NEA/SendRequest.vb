﻿Imports System.Text.RegularExpressions
Public Class SendRequest

    Private Sub SendRequest()
        ' Defines new connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Defines location of the database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
        ' Opens connection to the database
        conn.Open()
        Dim msg As String = txtMsg.Text
        ' SQL (Structured Query Lanugage) statement which inserts what the staff member input into the database in the corresponding table
        Dim sql As String = "INSERT INTO CustRequests(CustUser,RequestType,Message) VALUES ('" & CustomerLogin.txtUsername.Text & "', '" & RequestType.Text & "', """ & msg & """)"
        ' Allows the sql command to be executed against the database
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Customer is notififed of their success of their required task.
        MessageBox.Show("Request sent", "Sending of request successful")
        'Open Database Connection again
        sqlCom.Connection = conn

        ' Carry out the sql statement
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

        ' Close the connection to the database
        conn.Close()
        ' Clears all fields
        txtMsg.Clear()
        RequestType.Text = ""
    End Sub
    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides current form
        Me.Hide()
        ' Redirects them to customermenu
        CustomerMenu.Show()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        ' Clears all fields
        txtMsg.Clear()
        RequestType.Text = ""
    End Sub

    Private Sub BtnSend_Click(sender As Object, e As EventArgs) Handles BtnSend.Click
        ' If the user is sending an updating of details of request, and the message only consists of numbers, the user is notified this can't be done.
        If RequestType.SelectedItem = "Updating of details request" And IsNumeric(txtMsg.Text) = True Then
            MessageBox.Show("As you are requesting an updating of details, please ensure your message doesn't only consist of digits, as it is essential the staff member knows what field you want updated", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' If the request is less than 20 characters long, the user is informed that it must be longer
        ElseIf txtMsg.Text.Length < 20 Then
            MessageBox.Show("Please ensure that your message is at least 20 characters long", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' If the user hasn't specified what type of request they are sending, they are notified that this must be done
        ElseIf RequestType.SelectedItem = "" Then
            MessageBox.Show("Please ensure that you enter the type of request you want to send", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' If the user isn't making an updating of details request and has included any digits in their request, they are informed that this is unnecessary
        ElseIf RequestType.SelectedItem <> "Updating of details request" And Regex.Match(txtMsg.Text, "\d").Success And Regex.Match(txtMsg.Text, "\w").Success Then
            MessageBox.Show("Since you are not sending an updating of details request, your message should only contain letters. Please try again", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' message box is then cleared
            txtMsg.Clear()

            ' If the request has been validated, it can be sent
        Else
            SendRequest()
        End If
    End Sub
End Class